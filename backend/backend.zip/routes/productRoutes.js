const express = require("express");
const Product = require("../models/Product");
const Order = require("../models/Order");
const { protect, admin } = require("../middleware/authMiddleware");
const products = require("../data/products");

const router = express.Router();

//@route POST /api/products
//@desc Create a new product
//@access Private/Admin

router.post("/", protect, admin, async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      discountPrice,
      countInStock,
      category,
      brand,
      sizes,
      colors,
      collections,
      material,
      gender,
      images,
      isFeatured,
      isPublished,
      tags,
      dimensions,
      weight,
      sku,
    } = req.body;

    const product = new Product({
      name,
      description,
      price,
      discountPrice,
      countInStock,
      category,
      brand,
      sizes,
      colors,
      collections,
      material,
      gender,
      images,
      isFeatured,
      isPublished,
      tags,
      dimensions,
      weight,
      sku,
      user: req.user._id,
    });

    const createdProduct = await product.save();
    res.status(201).json(createdProduct);
  } catch (error) {
    console.log(error);
    res.status(500).send("Server Error");
  }
});
//@route Put /api/products/:id
//desc Update an existing peoductId
//@access  Private/Admin

router.put("/:id", protect, admin, async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      discountPrice,
      countInStock,
      category,
      brand,
      sizes,
      colors,
      collections,
      material,
      gender,
      images,
      isFeatured,
      isPublished,
      tags,
      dimensions,
      weight,
      sku,
    } = req.body;

    //Find product by ID

    const product = await Product.findById(req.params.id);
    if (product) {
      // Update Product Fields
      product.name = name || product.name;
      product.description = description || product.description;
      product.price = price ?? product.price;
      product.discountPrice = discountPrice || product.discountPrice;
      product.countInStock = countInStock || product.countInStock;
      product.category = category || product.category;
      product.brand = brand || product.brand;
      product.sizes = sizes || product.sizes;
      product.colors = colors || product.colors;
      product.collections = collections || product.collections;
      product.material = material || product.material;
      product.gender = gender || product.gender;
      product.images = images || product.images;
      product.isFeatured =
        isFeatured !== undefined ? isFeatured : product.isFeatured;
      product.isPublished =
        isPublished !== undefined ? isPublished : product.isPublished;

      product.tags = tags || product.tags;
      product.dimensions = dimensions || product.dimensions;
      product.weight = weight || product.weight;
      product.sku = sku || product.sku;

      //save the updated product

      const updateProduct = await product.save();
      res.json(updateProduct);
    } else {
      res.status(404).json({ message: "Product Not Found!" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send("Server Error");
  }
});
//@route Delete /api/products/:id
//@desc Delete a product by ID
//@access Private/Admin
router.delete("/:id", protect, admin, async (req, res) => {
  try {
    //Finding product By ID
    const product = await Product.findById(req.params.id);
    if (product) {
      //Remove From DAtaBAse
      await product.deleteOne();
      res.json({ message: "Product Removed" });
    } else {
      res.status(404).json({ message: "Product Not Found !" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send("Server Error");
  }
});

//@route get /api/products
//@desc get all products with optional query filters
//@access public
router.get("/", async (req, res) => {
  try {
    const {
      collection,
      size,
      color,
      gender,
      minPrice,
      maxPrice,
      sortBy,
      search,
      category,
      material,
      brand,
      limit,
    } = req.query;
    let query = {};

    //fILTER loGIC
    if (collection && collection.toLowerCase() !== "all") {
      query.collections = collection;
    }

    if (category && category.toLowerCase() !== "all") {
      query.category = category;
    }

    if (material) {
      query.material = { $in: material.split(",") };
    }
    if (brand) {
      query.brand = { $in: brand.split(",") };
    }
    if (size) {
      query.sizes = { $in: size.split(",") };
    }
    if (color) {
      query.colors = { $in: [color] };
    }
    if (gender) {
      query.gender = gender;
    }
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = Number(minPrice);
      if (maxPrice) query.price.$lte = Number(maxPrice);
    }
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
        { category: { $regex: search, $options: "i" } },
        { brand: { $regex: search, $options: "i" } },
        { gender: { $regex: search, $options: "i" } },
        { tags: { $in: [new RegExp(search, "i")] } },
      ];
    }

    // Sorting Logic
    let sort = {};
    if (sortBy) {
      switch (sortBy) {
        case "priceAsc":
          sort = { price: 1 };
          break;
        case "priceDesc":
          sort = { price: -1 };
          break;
        case "popularity":
          sort = { rating: -1 };
          break;
        default:
          break;
      }
    }
    let products = await Product.find(query)
      .sort(sort)
      .limit(Number(limit) || 0);
    res.json(products);
  } catch (error) {
    console.error(error);
    res.status(500).send("Server Error");
  }
});

//@route get /api/products/best-seller
//desc Retrive the Product with highest rating
//access Public

router.get("/best-seller", async (req, res) => {
  try {
    const bestSeller = await Product.findOne().sort({ rating: -1 });
    if (bestSeller) {
      res.json(bestSeller);
    } else {
      res.status(404).json({ message: "No Best Seller Found !" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send("Server Error");
  }
});
//@route Get /api/products/new-arrivals
//@desc Retrive latest 8 products - creation date
//@access Public

router.get("/new-arrivals", async (req, res) => {
  try {
    //Fetch latest 8 products
    const newArrivals = await Product.find({}).sort({ createdAt: -1 }).limit(8);

    res.json(newArrivals);
  } catch (error) {
    console.error(error);
    res.status(500).send("Server Error");
  }
});

//Route Get /api/products/similar/:id
//desc Retrive similar based on current PRODUCT's gender and category
//@access Public

router.get("/similar/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const product = await Product.findById(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found !" });
    }
    const similarProduct = await Product.find({
      _id: { $ne: id }, //Exclude the current product ID
      gender: product.gender,
      category: product.category,
    }).limit(4);
    res.json(similarProduct);
  } catch (error) {
    console.error(error);
    res.status(500).send("server Error");
  }
});

//@route GEt /Api/products/recommendations
//@desc get personalized recommendations
// @access Private
router.get("/recommendations", protect, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id });
    if (!orders || orders.length === 0) {
      return res.json([]);
    }

    // Extract all product IDs from all orders
    const purchasedProductIds = [];
    orders.forEach(order => {
      order.orderItems.forEach(item => {
        purchasedProductIds.push(item.productId);
      });
    });

    if (purchasedProductIds.length === 0) {
      return res.json([]);
    }

    // Find the categories of those purchased products
    const purchasedProducts = await Product.find({ _id: { $in: purchasedProductIds } });
    const categories = [...new Set(purchasedProducts.map(p => p.category))];

    if (categories.length === 0) {
      return res.json([]);
    }

    // Fetch up to 8 recommended products matching those categories, excluding the exact purchased items
    const recommendations = await Product.find({
      category: { $in: categories },
      _id: { $nin: purchasedProductIds }
    }).limit(8);

    res.json(recommendations);
  } catch (error) {
    console.error("Error in recommendations:", error);
    res.status(500).send("Server Error");
  }
});

//@route GEt /Api/products/:id
//@desc get a single product by ID
// @access Public

router.get("/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (product) {
      res.json(product);
    } else {
      res.status(404).json({ message: "Product not Found!" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send("server Error");
  }
});

module.exports = router;

